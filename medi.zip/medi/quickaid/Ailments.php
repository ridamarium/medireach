<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="stylesheet.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .fnt{
            font-family: Georgia, serif;
            padding: 8px;
            font-size: 2vw;
            padding-left: 70px;
        }
        body{
            background: url("image/bg1.avif") center/cover fixed;
        }
    </style>
</head>
<body>
    <div class="blur">
    <div class="background"></div> 
    <div class="text-container">
    <ul class="first-ul">
    <li style="float:left;
            border-right: 1px solid #4fd7b7;"><B><div class="fnt">MediReach</div></B></a></li>
        <li style="float:right"><a class="active" href="home.php">Home</a></li>
        <li><a href="quickA.php">Urgent-Care</a></li>
        <li><a href="Ailments.php">Ailments</a></li>
        <li><a href="beauty.php">Beauty</a></li>
    </ul><br>
    <div class="gallery-container">
    <div class="gallery-row">
        <div class="gallery">
        <a href="cough.php">
            <img src="image/cough.jpeg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Abdominal Pain</em><B></div>
        </div>
        <div class="gallery">
        <a href="headache.php">
            <img src="image/th.jpeg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Headache</em></B></div>
        </div>
        <div class="gallery">
        <a href="cramps.php">
            <img src="image/cramps.webp" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Muscle-Cramps</em><B></div>
        </div>
        <div class="gallery">
        <a href="reye.php">
            <img src="image/redeye.jpeg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Red Eye</em><B></div>
        </div>
    </div>
    <div class="gallery-row">
        <div class="gallery">
        <a href="acidity.php">
            <img src="image/acidity.jpeg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Acidity</em><B></div>
        </div>
        <div class="gallery">
        <a href="mouth-ulcers.php">
            <img src="image/ulcers.jpeg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Mouth Sores</em><B></div>
        </div>
        <div class="gallery">
            <a href="stomachache.php">
            <img src="image/stomach.jpg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Abdominal Pain</em><B></div>
        </div>
    </div>
    </div>
    </div>
    </div>
</body>
</html>
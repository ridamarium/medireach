<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="stylesheet.css">
        <style>
            .tab1 {
                tab-size:2;
            }
            .text-box {
                background-color: white;
                padding: 20px;
                border-radius: 10px;
                max-width: 800px; 
                margin: 0 auto; 
                box-shadow: 15px 15px 15px gray;
            }
        </style>
        <style>
body {
  background-image: url("image/bg2.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
    </head>
    <body>
    <ul class="first-ul">
    <li style="float:left;
            border-right: 1px solid #4fd7b7"><B><div class="fnt">MediReach</div></B></a></li>
        <li style="float:right"><a class="active" href="home.php">Home</a></li>
        <li><a href="quickA.php">Urgent-Care</a></li>
        <li><a href="Ailments.php">Ailments</a></li>
        <li><a href="beauty.php">Beauty</a></li>
    </ul>
        <B>
            <h1 style="padding-left:20px;color:#04AA6D;text-shadow: 2px 2px 5px gray;text-align: center;">
            Quick Remedies to Get Rilief from Acidity</h1>
            <div class="text-box">
        <div style="font-size: larger;">
        <?php
            echo '</br>';
            echo 'Headaches happen.' ;
            echo '</br>';
            echo 'The good news is there are several simple things you can do to ease the pain without a trip to the doctor.';
            echo '</br>'; 
            echo 'Try these tips and get to feeling better fast.';
        ?>
        <pre class="tab1">
            1. Eat a few basil leaves. <br>
            2. Chew sauf(Fennel) after meals.<br>
            3. rink cinnamon tea. <br>
            4. Drink a glass of chaas(Butter Milk) instead.<br>
            5. Chew a slice of fresh ginger.<br>
            6. Drink a glass of cold milk.<br>
            7. Drink coconut water.<br>
            8. Practice Relaxation.<br>
            9. Stop smoking if you smoke.<br>
            10. Peppermint Oil and Caraway Oil.<br>
            11. Use Meds in Moderation, such as Tums and Alka-Seltzer.
        </pre>  
        <h2>When to Call Your Doctor?</h2>
        If you experience indigestion along with the following symptoms, 
        you may have a more serious condition, and you should seek medical attention right away:
        <ul>
            <li>Bloody vomit</li>
            <li>Trouble swallowing</li>
            <li>Painful swallowing</li>
            <li>Chest pain</li>
            <li>Shortness of breath</li>
            <li>Sweating</li>
            <li>Severe, constant abdominal pain</li>
        </ul>
        </B>
        </div>
        </div>
    </body>
</html>

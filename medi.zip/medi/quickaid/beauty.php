<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="stylesheet.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .fnt{
            font-family: Georgia, serif;
            padding: 8px;
            font-size: 2vw;
            padding-left: 70px;
        }
        body{
            background: url("image/bg1.avif") center/cover fixed;
        }
    </style>
</head>
<body>
    <div class="blur">
    <div class="background"></div> 
    <div class="text-container">
    <ul class="first-ul">
    <li style="float:left;
            border-right: 1px solid #4fd7b7"><B><div class="fnt">MediReach</div></B></a></li>
        <li style="float:right"><a class="active" href="home.php">Home</a></li>
        <li><a href="quickA.php">Urgent-Care</a></li>
        <li><a href="Ailments.php">Ailments</a></li>
        <li><a href="beauty.php">Beauty</a></li>
    </ul><br>
    <div class="gallery-container">
    <div class="gallery">
        <a href="hair.php">
            <img src="image/hair.jpg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Hair Loss</em></B></div>
    </div>
    <div class="gallery">
        <a href="dry.php">
            <img src="image/dry.jpeg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Dryness</B></em></div>
    </div>
    <div class="gallery">
        <a href="dcircles.php">
            <img src="image/dcircles.jpg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Dark Cirles</B></em></div>
    </div>
    <div class="gallery">
        <a href="acne.php">
            <img src="image/acne.jpeg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Acne</B></em></div>
    </div>
    <div class="gallery">
        <a href="spots.php">
            <img src="image/darkspot.jpeg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Dark Spots</em></B></div>
    </div>
    <div class="gallery">
        <a href="heels.php">
            <img src="image/heels.jpeg" alt="hello" width="180" height="200" style="width: 180px; height: 200px;">
        </a>
        <div class="desc"><B><em>Cracked Heels</em></B></div>
    </div>
    </div>
    </div>
    </div>
</body>
</html>